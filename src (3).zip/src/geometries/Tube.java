package geometries;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

import java.util.List;

import static primitives.Util.isZero;

/**
 * class to represent tube
 */
public class Tube extends RadialGeometry implements Geometry {
    Ray _axisRay;

    /**
     * constructor
     *
     * @param _radius
     * @param _axisRay
     */
    public Tube(double _radius, Ray _axisRay) {
        super(_radius);
        this._axisRay = _axisRay;
    }

    /**
     * returns _axisRay
     *
     * @return Ray
     */
    public Ray get_axisRay() {
        return _axisRay;
    }

    /**
     * return normal
     *
     * @param point
     * @return Vector
     */
    public Vector getNormal(Point3D point) {

        //The vector from the point of the cylinder to the given point
        Point3D o = _axisRay.get_p0();
        Vector v = _axisRay.get_dir();
        Vector vector1 = o.subtract(point);
        //We need the projection to multiply the _direction unit vector
        double projection = vector1.dotProduct(v);
        if (!isZero(projection)) {
            // projection of P-O on the ray:
            o.add(v.scale(projection));
        }

        //This vector is orthogonal to the _direction vector.
        Vector check = o.subtract(point);
        return check.normalize();
    }

    @Override
    public String toString() {
        return "ray: " + _axisRay +
                ", radius: " + _radius;
    }
}

