package primitives;
import primitives.Vector;
import primitives.Point3D;
/**
 * class that represents a ray
 */

/**
 * Constructor for class Ray
 */
public class Ray {
    Point3D _p0;
    Vector _dir;

    /**
     * function that returns point of origin (p0)
     * @return Point3D
     */
    public Point3D get_p0() {
        return _p0;
    }

    /**
     * function that returns _dir(direction vector)
     * @return Vector
     */
    public Vector get_dir() {
        return _dir;
    }

    /**
     * constructor
     * @param _p0
     * @param _dir
     */
    public Ray(Point3D _p0, Vector _dir) {

        this._p0 = _p0;
        if(_dir.length()!=1)
        {this._dir=_dir.normalize();}
        this._dir = _dir;
    }
}