package unittests;

import org.junit.Test;
import renderer.ImageWriter;

public class ImageWriterTest {
    @Test
    public void setImagew() {

    ImageWriter imagew=new ImageWriter("first test",1600,1000,800,500);
    }

}
