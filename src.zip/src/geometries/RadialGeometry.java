package geometries;

/**
 * class that represents an abstact class that has a radius
 */
public abstract class RadialGeometry {
    double _radius;

    /**
     * constructor
     * @param _radius
     */
    public RadialGeometry(double _radius) {
        this._radius = _radius;
    }

    /**
     * copy constructor
     * @param other
     */
    public  RadialGeometry (RadialGeometry other)
    {
        this._radius = other._radius;
    }

    /**
     * return _radius
     * @return
     */
    public double get_radius() {
        return _radius;
    }

    public void set_radius(double _radius) {
        this._radius = _radius;
    }
}
