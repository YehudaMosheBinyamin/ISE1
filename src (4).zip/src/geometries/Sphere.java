package geometries;

import primitives.Coordinate;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

import java.util.List;

import static primitives.Util.alignZero;

/**
 * class that represents sphere
 */
public class Sphere extends RadialGeometry implements Geometry{
    Point3D _center;

    /**
     * constructor
     * @param _radius
     * @param _center
     */
    public Sphere(double _radius, Point3D _center) {
        super(_radius);
        this._center = _center;
    }

    /**
     * returns normal
     * @param _other
     * @return Vector
     */
    public Vector getNormal(Point3D _other){
        return  _center.subtract(_other).normalize();
        //return  getNormal(new Coordinate(_other.get_x().get()-_center.get_x().get()),
         //       new Coordinate(_other.get_x().get()));
    }

    /**
     * returns _center
     * @return Point3D
     */
    public Point3D get_center() {
        return _center;
    }

    @Override
    public String toString() {
        return "Sphere{" +
                "_center=" + _center +
                '}';
    }
}
