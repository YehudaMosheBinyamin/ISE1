package unittests;

import org.junit.Test;

import static org.junit.Assert.*;

public class CylinderTest {

    @Test
    public void get_height() {
    }

    @Test
    public void testToString() {
    }

    @Test
    public void getNormal() {
    }
}