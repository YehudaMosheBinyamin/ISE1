package elements;

import primitives.Color;

/**
 * class to represent AmbientLight
 */
public class AmbientLight {
    Color _intensity;
   // Color _iP;

    public AmbientLight(Color iA,double kA)
    {
        _intensity=iA.scale(kA);
    }

    /**
     * getter for intensity
     * @return Color
     */
    public Color get_intensity() {
       return  _intensity;
    }
}
