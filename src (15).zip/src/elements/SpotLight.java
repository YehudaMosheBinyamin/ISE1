package elements;

import primitives.Color;
import primitives.Point3D;
import primitives.Vector;

/**
 *
 */
public class SpotLight extends PointLight {
    Vector _direction;
    public SpotLight(Color _intensity, Point3D _position,
                     double _kC, double _kL, double _kQ, Vector _direction)
    {
        super(_intensity, _position, _kC, _kL, _kQ);
        this._direction = _direction;
    }

    @Override
    public Color getIntensity(Point3D point) {
       return super.getIntensity(point) ;
    }

    @Override
    public Vector getL(Point3D point) {
        double dirl=_direction.dotProduct(l);
        double answer;
        if(dirl>0)
        {answer=dirl;}
        else{
            answer=0;
        }
        Vector il=(getIntensity(point).scale(answer)).scale(1/(_kC+_direction.scale(_kL)+(_direction.scale(_kQ)));
        return il;
    }
}
