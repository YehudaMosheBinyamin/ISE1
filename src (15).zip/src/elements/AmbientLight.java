package elements;

import primitives.Color;

/**
 * class to represent AmbientLight
 */
public class AmbientLight extends Light {

   // Color _iP

    public AmbientLight(Color iA,double kA)
    {
       super(iA.scale(kA));
    }

}
