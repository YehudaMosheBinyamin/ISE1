package geometries;
import primitives.Point3D;
import primitives.Ray;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * class for adding intersections of ray with more than one geometries which have intersections with ray.
 * intersections will be add to ArrayList (chosen for quick addition ability)
 */
public class Geometries implements Intersectable {
    public LinkedList<Intersectable> l1 = new LinkedList<Intersectable>();
/********constructors******************/
    public Geometries() {
        this.l1 = null;
    }

    public Geometries(Intersectable... geometries)
    {
        this.l1 = l1;
    }

    /**
     * adds an intersection to ArrayList of intersections
     * @param geometries
     */
    public void add(Intersectable... geometries)
    { //Iterator _geometries=l1.iterator();
        if (geometries.length > 0) {
            for (Intersectable geom : geometries) {
                l1.add(geom);

            }
        }
    }
    @Override
    public LinkedList<Geopoint> findIntersections(Ray ray) {
        return null;
    }

}