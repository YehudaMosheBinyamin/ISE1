package geometries;
import primitives.Color;
import primitives.Material;
import primitives.Point3D;
import primitives.Vector;

/**
 * interface to force implementation of getNormal
 */
public abstract class Geometry implements Intersectable{
    protected Color _emmission;
    protected Material _material;

    public Geometry(Color _emmission, Material _material) {
        this._emmission = _emmission;
        this._material = _material;
    }

    /**
     *
     * @return Material
     */
    public Material get_material() {
        return _material;
    }

    public abstract Vector getNormal(Point3D point);

    /**
     * returns emmission
     * @return Color
     */
    public Color get_emmission() {
        return _emmission;
    }
    public Geometry(Color emmi){
        _emmission=emmi;
    }
    public Geometry()
    {
        this(Color.BLACK,new Material(0,0,0));

    }
}

