package renderer;
import elements.Camera;
import geometries.Geometry;
import geometries.Intersectable;
import primitives.Color;
import primitives.Point3D;
import primitives.Ray;
import scene.Scene;
import java.util.LinkedList;
import java.util.List;

import static java.lang.Float.POSITIVE_INFINITY;

/**
 * class to render image based on geometries ,light and color
 */
public class Render
{
    Scene _scene;
    ImageWriter _imageWriter;

    /**
     * function that renders an image
     */
    public void renderImage(){
        Camera camera = _scene.getCamera();
        Intersectable geometries = _scene.getGeometries();
        java.awt.Color background = _scene.getBackground().getColor();
        int nX = _imageWriter.get_nX();
        int nY=_imageWriter.getNy();
        double distance=_scene.get_distance();
        double height=_imageWriter.getHeight();
        double width=_imageWriter.getWidth();

        //for each point (i,j) in the view plane // i is pixel row number and j is pixel in the row number
        for(int i=0;i<=nY;i++) {
            for (int j = 0; j <= nX; j++) {
                Ray ray = camera.constructRayThroughPixel(nX, nY, j, i, distance, width, height);
                LinkedList<Intersectable.Geopoint> intersectionPoints = geometries.findIntersections(ray);
                if (intersectionPoints.isEmpty()) {
                    _imageWriter.writePixel(j, i, background);
                }
                else
                {
                   Intersectable.Geopoint closestpoint=getClosestPoint(ray);
                _imageWriter.writePixel(j, i, calcColor(closestpoint,ray).getColor());}

            }
        }}

    /**
     * function that finds the closest intersection with ray and geometries
     * @param intersectionPoints
     * @return
     */
    private Intersectable.Geopoint getClosestPoint(List<Intersectable.Geopoint> intersectionPoints)
    {
        Intersectable.Geopoint closest = intersectionPoints.get(0);
    for (Intersectable.Geopoint geopoint : intersectionPoints) {
        if ((_scene.get_camera().get_p0().distance(geopoint.getPoint())>_scene.get_camera().get_p0().distance(closest.getPoint())))
            closest=geopoint;

    }
    return closest;
}

    /**
     * to find closest intersection of ray with scene
     * @param ray
     * @return Intersectable.Geopoint
     */
    private Intersectable.Geopoint getClosestPoint(Ray ray)
    {
       Intersectable.Geopoint closest=null;
       double closestDistance=POSITIVE_INFINITY;
       Point3D ray_p0=ray.get_p0();
       List<Intersectable.Geopoint>intersectionList=_scene.get_geometries().findIntersections(ray);
       for (Intersectable.Geopoint geopoint : intersectionList) {
            if (ray_p0.distance(geopoint.getPoint())<closestDistance)
                closest=geopoint;
            closestDistance=ray_p0.distance(geopoint.getPoint());

        }
        return closest;
    }

    //In the intersectionPoints - find the point with minimal distance from the ray
   // begin point (now it is just the camera location) and return it
private Color calcColor(Intersectable.Geopoint geopoint,Ray ray){

        Color color= _scene.get_ambientLight().get_intensity();
        color=color.add(_scene.get_ambientLight().get_intensity());
        return color;
}
    public void printGrid(int interval, java.awt.Color colorsep) {
        double rows = this._imageWriter.getNy();
        double coloumns = _imageWriter.getNx();
        //Writing the lines.
        for (int row = 0; row < rows; ++row) {
            for (int collumn = 0; collumn < coloumns; ++collumn) {
                if (collumn % interval == 0 || row % interval == 0) {
                    _imageWriter.writePixel(collumn, row, colorsep);
                }
            }
        }
    }
    public void writeToImage() {
        _imageWriter.writeToImage();
    }

}

