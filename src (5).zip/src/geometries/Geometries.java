package geometries;

import primitives.Point3D;
import primitives.Ray;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Geometries {
    ArrayList<Intersectable> l1=new ArrayList<Intersectable>();

    public Geometries() {
        this.l1 =null;
    }

    public Geometries(Intersectable... geometries) {
        this.l1 = l1;
    }
    public void add (Intersectable...geometries)
    { Iterator it=l1.iterator();
        if(l1.size()==0)
        {
        }


        for(it.hasNext()){
            it=l1.add(l1.size());

        }

    }
    List<Point3D>indIntersections(Ray ray)
    {
        return null;
    }

}
