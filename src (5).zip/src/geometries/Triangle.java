package geometries;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

import java.awt.*;

import static primitives.Util.isZero;

/**
 *class that represents a triangle in a 3d environment
 */
public class Triangle extends Polygon {//****CONSTRUCTOR*****/

    public Triangle(Point3D p1, Point3D p2, Point3D p3) {
        super(p1, p2, p3);
    }

    /**
     * return vector normal
     *
     * @param _other
     * @return Vector
     */
    public Vector getNormal(Point3D _other) {
        return (super.getNormal(_other));
    }

    @Override
    public String toString() {
        String result = "";
        for (Point3D p : _vertices) {
            result += p.toString();
        }
        return result;
    }
}
