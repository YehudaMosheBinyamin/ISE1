package unittests;

import renderer.ImageWriter;

public class ImageWriterTest {
    ImageWriter imagew=new ImageWriter("first test",1600,1000,800,500);
}
